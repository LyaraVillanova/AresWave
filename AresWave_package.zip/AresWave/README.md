# AresWave
AresWave is a Python package for source parameter estimation of marsquakes through waveform fitting using a modified DSMpy. This version runs under Visual Studio Code + WSL/Ubuntu.

See docs/USAGE.md for usage examples (S0185a event).